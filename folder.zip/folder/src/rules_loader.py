# src/rules_loader.py
import PyPDF2

def load_rubric_from_pdf(path: str) -> str:
    """
    從 PDF 中讀取文字並回傳成純文字字串
    """
    text_content = []
    with open(path, "rb") as f:
        reader = PyPDF2.PdfReader(f)
        for page in reader.pages:
            text = page.extract_text()
            if text:
                text_content.append(text.strip())
    return "\n".join(text_content)


if __name__ == "__main__":
    # 測試
    pdf_path = "C:/origindesk/school_project/interview-sim/inputs/rubric.pdf"
    rules = load_rubric_from_pdf(pdf_path)
    print("=== 抽取的規則文字 ===")
    print(rules[:1000])  # 先印前 1000 字看效果


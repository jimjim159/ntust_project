# src/llm_scoring.py
import requests, json
from textwrap import dedent

# 你在 Windows 本機 → localhost OK。若在 WSL，改成 http://<WSL-IP>:11434
OLLAMA_URL = "http://localhost:11434"
MODEL_NAME = "qwen2.5:7b-instruct"  # 與 `ollama list` 一致

SYSTEM_PROMPT = "你是一位嚴謹的面試評分官，必須嚴格遵守評分規則與打分格式。"

def _health_check(timeout=5):
    r = requests.get(f"{OLLAMA_URL}/api/tags", timeout=timeout)
    r.raise_for_status()

def build_prompt(rubric_text: str, candidate_script: str) -> str:
    return dedent(f"""
    [任務]
    依下列「評分規則」對「面試講稿」進行評分與簡要講評，最後給出 0~100 的整數總分。

    [評分規則 / Rubric]
    {rubric_text}

    [面試講稿]
    {candidate_script}

    [輸出格式（務必遵守）]
    - 各維度重點觀察（項列）
    - 具體優點（項列）
    - 具體待改善（項列）
    - 總評（不超過 80 字）
    - 總分（0~100 的整數；僅數字）
    """)

def score_with_ollama(rubric_text: str, candidate_script: str, timeout: int = 600):
    """
    用串流 /api/generate，避免整段等待造成超時；timeout 拉到 600s。
    """
    _health_check()

    payload = {
        "model": MODEL_NAME,
        "prompt": f"{SYSTEM_PROMPT}\n\n{build_prompt(rubric_text, candidate_script)}",
        "stream": True,
        "options": {
            "temperature": 0.2,
            "num_ctx": 8192
        },
        "keep_alive": "10m"
    }

    with requests.post(f"{OLLAMA_URL}/api/generate", json=payload, stream=True, timeout=timeout) as resp:
        resp.raise_for_status()
        chunks = []
        for line in resp.iter_lines(decode_unicode=True):
            if not line:
                continue
            try:
                obj = json.loads(line)
                piece = obj.get("response", "")
                if piece:
                    chunks.append(piece)
                if obj.get("done"):
                    break
            except Exception:
                continue
        return "".join(chunks).strip()

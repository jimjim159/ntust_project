# src/main.py
import os
from pydantic import BaseModel
from emotion_infer import EmotionScorer
from rules_loader import load_rubric_from_pdf
from llm_scoring import score_with_ollama
import requests

def warm_up_model(model_name="mistral", url="http://localhost:11434"):
    print(f"[WarmUp] 正在預載模型: {model_name}")
    payload = {"model": model_name, "prompt": "hi", "stream": False, "keep_alive": "10m"}
    try:
        r = requests.post(f"{url}/api/generate", json=payload, timeout=600)
        r.raise_for_status()
        print(f"[WarmUp] {model_name} 已載入完成")
    except Exception as e:
        print(f"[WarmUp] {model_name} 預載失敗: {e}")

# === 路徑設定 ===
RUBRIC_PATH = "C:/origindesk/school_project/interview-sim/inputs/rubric.pdf"
SCRIPT_PATH = "C:/origindesk/school_project/interview-sim/inputs/script.txt"
VIDEO_PATH  = "C:/origindesk/school_project/interview-sim/inputs/video.mp4"

LLM_WEIGHT = 0.8
EMO_WEIGHT = 0.2

class FinalReport(BaseModel):
    llm_raw_feedback: str
    emotion_detail: dict
    llm_total_score: int
    emotion_score: float
    final_score: float

def extract_llm_total_score(llm_text: str) -> int:
    lines = [x.strip() for x in llm_text.splitlines() if x.strip()]
    for line in reversed(lines):
        try:
            val = int(line)
            if 0 <= val <= 100:
                return val
        except:
            continue
    return 60  # fallback

def main(use_webcam=False):
    # 0) 先暖機（要跑 mistral 就留著；要暖 qwen 就改成 "qwen2.5:7b-instruct"）
    warm_up_model("qwen2.5:7b-instruct")
  # ← 如果你要直接暖 qwen：warm_up_model("qwen2.5:7b-instruct")

    # 1) 載入規則（PDF）
    if not os.path.exists(RUBRIC_PATH):
        raise FileNotFoundError(f"找不到規則檔: {RUBRIC_PATH}")
    rubric_text = load_rubric_from_pdf(RUBRIC_PATH)

    # 2) 載入面試講稿
    if not os.path.exists(SCRIPT_PATH):
        raise FileNotFoundError(f"找不到面試講稿：{SCRIPT_PATH}")
    with open(SCRIPT_PATH, "r", encoding="utf-8") as f:
        candidate_script = f.read()

    # 3) 語言模型評分（llm_scoring.py 請用串流+長 timeout 的版本）
    llm_feedback = score_with_ollama(rubric_text, candidate_script)
    llm_score = extract_llm_total_score(llm_feedback)

    # 4) 情緒分析（影片或 webcam）
    emo = EmotionScorer()
    if use_webcam:
        emotion_detail = emo.score_from_video(use_webcam=True)
    else:
        if os.path.exists(VIDEO_PATH):
            emotion_detail = emo.score_from_video(video_path=VIDEO_PATH)
        else:
            emotion_detail = {"emotion_score": 80.0, "note": "未提供影片，使用預設分數"}
    emotion_score = float(emotion_detail.get("emotion_score", 80.0))

    # 5) 加權總分
    final_score = round(LLM_WEIGHT * llm_score + EMO_WEIGHT * emotion_score, 1)

    report = FinalReport(
        llm_raw_feedback=llm_feedback,
        emotion_detail=emotion_detail,
        llm_total_score=llm_score,
        emotion_score=emotion_score,
        final_score=final_score
    )

    # 6) 輸出結果
    print("\n===== LLM 評分與講評 =====")
    print(report.llm_raw_feedback)
    print("\n===== 情緒評估 =====")
    print(report.emotion_detail)
    print("\n===== 加權總分 =====")
    print(f"LLM 總分: {report.llm_total_score} / 100")
    print(f"情緒分數: {report.emotion_score} / 100")
    print(f"最終分數: {report.final_score} / 100")

if __name__ == "__main__":
    main(use_webcam=False)

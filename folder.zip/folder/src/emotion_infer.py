# src/emotion_infer.py
import cv2
import numpy as np
from tensorflow.keras.models import load_model

# 🔹 你的模型固定路徑
MODEL_PATH = "C:/origindesk/school_project/interview-sim/models/smile_nervous_public.h5"

class EmotionScorer:
    def __init__(self):
        # 直接載入你的模型
        self.model = load_model(MODEL_PATH)
        self.labels = ["smile", "nervous"]

    def _predict_frame(self, frame_bgr: np.ndarray) -> dict:
        # 轉成 224x224（假設你訓練時就是這個尺寸）
        img = cv2.resize(frame_bgr, (224, 224))
        img = img.astype("float32") / 255.0
        img = np.expand_dims(img, axis=0)
        probs = self.model.predict(img, verbose=0)[0]
        return {self.labels[i]: float(probs[i]) for i in range(len(self.labels))}

    def score_from_video(self, video_path=None, use_webcam=False, sample_every_n_frames: int = 10):
        """
        從影片或 webcam 抽幀，輸出平均情緒與分數
        """
        if use_webcam:
            cap = cv2.VideoCapture(0)
        else:
            if not video_path:
                raise FileNotFoundError("請提供影片路徑或設定 use_webcam=True")
            cap = cv2.VideoCapture(video_path)

        frame_idx = 0
        nervous_probs, smile_probs = [], []
        prev_nervous, nervous_spikes = None, 0

        while True:
            ret, frame = cap.read()
            if not ret:
                break
            if frame_idx % sample_every_n_frames == 0:
                pred = self._predict_frame(frame)
                nervous, smile = pred["nervous"], pred["smile"]
                nervous_probs.append(nervous)
                smile_probs.append(smile)

                # spike：nervous > 0.7 且比前一次高很多
                if prev_nervous is not None and nervous > 0.7 and (nervous - prev_nervous) > 0.2:
                    nervous_spikes += 1
                prev_nervous = nervous
            frame_idx += 1

        cap.release()

        if not nervous_probs:
            return {
                "avg_nervous": None,
                "avg_smile": None,
                "nervous_spikes": 0,
                "emotion_score": None,
                "note": "沒有抓到任何有效畫面"
            }

        avg_nervous = float(np.mean(nervous_probs))
        avg_smile = float(np.mean(smile_probs))

        # 🔹 簡單算一個 0~100 分
        base = 50 + (avg_smile - avg_nervous) * 50
        penalty = min(nervous_spikes * 5, 30)
        emotion_score = max(0, min(100, base - penalty))

        return {
            "avg_nervous": avg_nervous,
            "avg_smile": avg_smile,
            "nervous_spikes": nervous_spikes,
            "emotion_score": round(emotion_score, 1),
        }
